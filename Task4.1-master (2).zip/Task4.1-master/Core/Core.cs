﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Task4._1.Core
{
    internal class Core
    {
        public static class CoreNavigate
        {
            public static Frame MC { get; set; }
        }
    }
}
